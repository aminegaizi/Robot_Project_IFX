/*
 * GTM_ISR.c
 *
 *  Created on: 29.11.2018
 *      Author: Gaizi
 */

#include "GTM_ISR.h"

volatile uint8 forward_flag = 0;
volatile uint8 stop_flag = 0;
volatile uint8 flag_s2 =0;

extern volatile int enable_obstacle_FSM;
extern volatile int obstacle_FSM;
extern volatile float64 distance_obstacle;

extern volatile float frequency_servo;
IfxGtm_Atom_Timer timerOneMs;
IfxGtm_Atom_Timer timerPositionUpdate;
IfxGtm_Atom_Timer timerServoDutyUpdate;
uint32 Flag_isr = 0;
extern Ifx_STM *stm_sfr;
IFX_INTERRUPT(ISR_Timer_1ms, 0, INTERRUPT_TIMER_1MS);
IFX_INTERRUPT(ISR_ObstacleAvoidance, 0, PRIORITY_ISR_POSITION);
extern IfxStm_CompareConfig config_servo;


void ISR_Timer_1ms(void)
{
    IfxCpu_enableInterrupts();
    send_sensor_data();
    IfxGtm_Atom_Timer_acknowledgeTimerIrq(&timerOneMs);
}

void GtmAtomTimer_initTimer(void)
{
       /* GTM TOM configuration */
        IfxGtm_Atom_Timer_Config timerConfig;
        IfxGtm_Atom_Timer_initConfig(&timerConfig, &MODULE_GTM);
        timerConfig.base.frequency       = 13;
        timerConfig.base.isrPriority     = INTERRUPT_TIMER_1MS;
        timerConfig.base.isrProvider     = IfxSrc_Tos_cpu0;
        timerConfig.base.minResolution   = (1.0 / timerConfig.base.frequency) / 1000;
        timerConfig.base.trigger.enabled = FALSE;
        timerConfig.atom                 = IfxGtm_Atom_1;
        timerConfig.timerChannel         = IfxGtm_Atom_Ch_0;
        timerConfig.clock                = IfxGtm_Cmu_Clk_0;
        IfxGtm_Atom_Timer_init(&timerOneMs, &timerConfig);

        IfxGtm_Atom_Timer_run(&timerOneMs);
}

void ISR_ObstacleAvoidance(void)
{
    IfxCpu_enableInterrupts();
    if (distance_obstacle != 0 && distance_obstacle >= 4e3)
    {
    	obstacle_FSM = 1;
    	Forward_1();
    }
    else if(distance_obstacle != 0 && distance_obstacle<= 4e3)
    {
    	obstacle_FSM = 0;
    	//Motors_stop();
    	Turn(90);
    }
    //Flag_isr++;
    IfxGtm_Atom_Timer_acknowledgeTimerIrq(&timerPositionUpdate);
}

void GtmAtomTimer_initTimer2(void)
{
       /* GTM TOM configuration */
        IfxGtm_Atom_Timer_Config timerConfig;
        IfxGtm_Atom_Timer_initConfig(&timerConfig, &MODULE_GTM);
        timerConfig.base.frequency       = 10;
        timerConfig.base.isrPriority     = PRIORITY_ISR_POSITION;
        timerConfig.base.isrProvider     = IfxSrc_Tos_cpu0;
        timerConfig.base.minResolution   = (1.0 / timerConfig.base.frequency) / 1000;
        timerConfig.base.trigger.enabled = FALSE;
        timerConfig.atom                 = IfxGtm_Atom_2;
        timerConfig.timerChannel         = IfxGtm_Atom_Ch_0;
        timerConfig.clock                = IfxGtm_Cmu_Clk_0;
        IfxGtm_Atom_Timer_init(&timerPositionUpdate, &timerConfig);

        IfxGtm_Atom_Timer_run(&timerPositionUpdate);
}


