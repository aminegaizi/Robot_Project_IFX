/**
 * \file Cpu0_Main.c
 * \brief Main function definition for Cpu core 0 .
 *
 * \copyright Copyright (c) 2018 Infineon Technologies AG. All rights reserved.
 *
 *
 *
 *                                 IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 */

#include "Cpu0_Main.h"

IfxCpu_syncEvent cpuSyncEvent= 0;


char object_detect;
int state_machine,enable_flag=0;
char angle[10];
char distance[10];
int i,A,D;

extern volatile float duty3;

volatile int obstacle_FSM = 0;
volatile int enable_obstacle_FSM = 0;

volatile uint8 iterator_s = 0;
extern volatile uint32 interruptLeft_counter;
extern volatile uint32 interruptRight_counter;
extern current_position Current_position;


volatile float64 distance_obstacle = 0;
volatile float64 temp = 0;
extern volatile float orientation_angle;

sint32 Fsys = 0;
char Right_encoder [5] = "";
char Duty_servo [5] = "";
char Left_encoder [5] = "";
char Distance_Obstacle[5] = "";
char Xpos[7] = "";
char Ypos[7] = "";
char Anglepos[7] = "";

int core0_main (void)
{
    IfxCpu_enableInterrupts();
    /*
     * !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
     * Enable the watchdog in the demo if it is required and also service the watchdog periodically
     * */
    IfxScuWdt_disableCpuWatchdog (IfxScuWdt_getCpuWatchdogPassword ());
    IfxScuWdt_disableSafetyWatchdog (IfxScuWdt_getSafetyWatchdogPassword ());

    /* Cpu sync event wait*/
	IfxCpu_emitEvent(&cpuSyncEvent);
	IfxCpu_waitEvent(&cpuSyncEvent, 1);

	initTime();
	ClockConfig();
	//beep();

	Motors_initialization();
	Init_gyro(); //Uncomment MPU init
	Encoders_config();
	serial_config();
	serial_config_Raspberry();


	//ultrasonic sensor config
	configUltrasonicSensor();
	sendTrig(IfxPort_P14_4);
	serial_config_Raspberry();
	//servomotor config
	config_servomotor();
	sweep_servo_config();
	SERVO_ISR_CONFIG();
	
	move_servo(45);
	GtmAtomTimer_initTimer();
	GtmAtomTimer_initTimer2();
    while (1)
    {
    	position_data();
    	if(D<30)
    	{
        	beep();
    	}
		sweep_servo();

    }
    return (1);
}

void command(char recv)
{
	serial_send(recv);
	switch(recv){
		case 'w':
			Forward_1();//go forward
			break;
		case 's':
			Backward_1();//go backward
			break;
		case 'a':
			Left();//turn left
			break;
		case 'd':
			Right();//turn right
			break;
		case 'q':
			Motors_stop();//stop
			break;
		case 'r':
			F_RightCurb();
			break;
		case 'e':
			F_LeftCurb();
			break;
		case 'f':
			B_RightCurb();
			break;
		case 'g':
			B_LeftCurb();
			break;
		default:
			break;
		}
}

void Raspberry_rcv(char recv)
{
	switch(state_machine){
		case 0:
			if(recv == '+'){ //START bit
				enable_flag = 1;
			}
			if(recv == '!'){
				state_machine = 1;
			}
			break;
		case 1:
			if(enable_flag == 1){
				if(recv == '!'){
					state_machine = 2;
				}
				else{
					object_detect = recv;//Which object is detected ? [S,E or numbers from 1 to 5]
				}
			}
			break;
		case 2:
			if(enable_flag == 1){
				if(recv == '!'){
					state_machine = 3;
					i=0;
				}
				else{
					angle[i] =  recv; //Angle of detection
					i++;
				}
			}
			break;
		case 3:
			if(enable_flag == 1){
				if(recv == '!'){
					state_machine = 4;
					i=0;
				}
				else{
					distance[i] =  recv; //Range of detection
					i++;
				}
			}
			break;
		case 4:
			if(recv == '-' && enable_flag == 1){ //STOP bit
				enable_flag = 0;
			}
			if(recv == '!'){
				state_machine = 0;
				A = atoi(angle);
				D = atoi(distance);
			}
			break;
		default: //Case nothing
			enable_flag = 0;
			state_machine = 0;
			break;
	}
}

void Serial_sensor_data_init()
{
	serial_send('a');
	serial_send('0');
	serial_send(' ');
	serial_send('b');
	serial_send('0');
	serial_send(' ');
	serial_send('c');
	serial_send('0');
	serial_send(' ');
	serial_send('x');
	serial_send('0');
	serial_send(' ');
	serial_send('y');
	serial_send('0');
	serial_send(' ');
	serial_send('t');
	serial_send('0');
	serial_send(' ');
}

void send_sensor_data()
{

	serial_send(' ');
	uint8 iterator_s = 0;

//	sprintf(Distance_Obstacle, "%lf", temp/10);
	serial_send('d');
	for(iterator_s = 0; iterator_s < 5; iterator_s++)
	{serial_send(distance[iterator_s]);}
	serial_send(' ');

	sprintf(Duty_servo, "%f", duty3);
	serial_send('b');
	for(iterator_s = 0; iterator_s < 5; iterator_s++)
	{serial_send(Duty_servo[iterator_s]);}
	serial_send(' ');
//
//	sprintf(Right_encoder, "%lu", interruptRight_counter);
	serial_send('a');
	for(iterator_s = 0; iterator_s < 5; iterator_s++)
	{serial_send(angle[iterator_s]);}
	serial_send(' ');
//
//	sprintf(Xpos, "%lf", Current_position.x);
//	serial_send('x');
//	for(iterator_s = 0; iterator_s < 7; iterator_s++)
//	{serial_send(Xpos[iterator_s]);}
//	serial_send(' ');
//
//	sprintf(Ypos, "%lf", Current_position.y);
//	serial_send('y');
//	for(iterator_s = 0; iterator_s < 7; iterator_s++)
//	{serial_send(Ypos[iterator_s]);}
//	serial_send(' ');

//	sprintf(Anglepos, "%lf", Current_position.theta);
//	serial_send('t');
//	for(iterator_s = 0; iterator_s < strlen(Anglepos); iterator_s++)
//	{serial_send(Anglepos[iterator_s]);}
//	serial_send(' ');

//	sprintf(Anglepos, "%f", orientation_angle);
//	serial_send('t');
//	for(iterator_s = 0; iterator_s < 7; iterator_s++)
//	{serial_send(Anglepos[iterator_s]);}
//	serial_send(' ');
}

