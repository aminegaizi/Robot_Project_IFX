package joystick.test.joystick;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static java.lang.Boolean.FALSE;
import static java.lang.Math.abs;


public class main extends AppCompatActivity implements JoystickView.JoystickListener {

    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;
    private static Set<BluetoothDevice> devices;
    final BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); // Represent the device's own Bluetooth adapter
    Activity activity;
    OutputStream mOutputStream;
    InputStream mInputStream;
    Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
    ArrayList<String> deviceName = new ArrayList<String>();
    ArrayList<String> deviceHardwareAddress= new ArrayList<String>();
    ArrayList<UUID> devicesUuid= new ArrayList<UUID>();
    ArrayList<BluetoothDevice> devicesList = new  ArrayList<BluetoothDevice>();
    CharSequence Connection = "Connecting...";
    CharSequence FailedConnection = "Connecting...";
    CharSequence Connected = "Connected";
    CharSequence NotConnected = "Not connected";
    int duration = Toast.LENGTH_SHORT;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CreateJoystick();
        CreateLabels();
        initiate_Bluetooth();
        CreateSpinner();
    }
    
    ///////////////////////////////////////////////////////OK/////////////////////////////////////
    public void onJoystickMoved(float xPercent, float yPercent, int id)
    {
        String avancer="w";
        String reculer="s";
        String droite="d";
        String gauche="a";
        String arret="q";
        String avantGauche="e";
        String avantDroite="r";
        String reculerGauche="f";
        String reculerDroite="g";
        UpdateLabels(xPercent, yPercent);
            if(xPercent>0.85)
            {
                Log.d("onJoystickMoved :", "droite");
                try {
                    sendData(droite);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if(xPercent<-0.85)
            {
                //gauche
                Log.d("onJoystickMoved :", "gauche");
                try {
                    sendData(gauche);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            else if(yPercent>0.85)
            {
                //avancer
                Log.d("onJoystickMoved :", "avancer");
                try {
                    sendData(avancer);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if(yPercent<-0.85)
            {
                //reculer
                Log.d("onJoystickMoved :", "reculer");
                try {
                    sendData(reculer);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if((xPercent==0) && (yPercent==0))
            {
            // arret
            Log.d("onJoystickMoved :", "arret");
            try {
                sendData(arret);
            } catch (IOException e) {
                e.printStackTrace();
            }
            }
            else if((xPercent>0.65 && xPercent<0.85)&&(yPercent<-0.35 && yPercent>-0.85)){
            //Arrière droit
            Log.d("onJoystickMoved :", "arriere droit");
            try {
                sendData(reculerDroite);
            } catch (IOException e) {
                e.printStackTrace();
            }
            }
            else if((xPercent<-0.65 && xPercent>-0.85)&&(yPercent<-0.35 && yPercent>-0.85)){
            //Arrière gauche
            Log.d("onJoystickMoved :", "arriere gauche");
            try {
                sendData(reculerGauche);
            } catch (IOException e) {
                e.printStackTrace();
            }
            }
            else if((xPercent>0.65 && xPercent<0.85)&&(yPercent>0.35 && yPercent<0.85)){
            //Arrière gauche
            Log.d("onJoystickMoved :", "avant droite");
            try {
                sendData(avantDroite);
            } catch (IOException e) {
                e.printStackTrace();
            }
            }
            else if((xPercent<-0.65 && xPercent>-0.85)&&(yPercent>0.35 && yPercent<0.85)){
            //Arrière gauche
            Log.d("onJoystickMoved :", "avant gauche");
            try {
                sendData(avantGauche);
            } catch (IOException e) {
                e.printStackTrace();
            }
            }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void CreateSpinner()
    {
        MyReference.spinner = new Spinner(this);
        MyReference.bluetooth_names = new ArrayList<String>();
        MyReference.bluetooth_names.add("Devices available");
        MyReference.dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, MyReference.bluetooth_names);
        MyReference.dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        MyReference.spinner.setAdapter(MyReference.dataAdapter);
        MyReference.spinner.setBackgroundColor(Color.rgb(255,255,255));
        addContentView(MyReference.spinner,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
        MyReference.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i!=0) {
                    Context context = getApplicationContext();
                    Toast toastConnection = Toast.makeText(context, Connection, duration);
                    toastConnection.show();
                    Log.d("DEBUGGUEUR=", "onItemSelected");
                    Log.d("DEBUGGUEUR=", deviceName.get(i - 1));
                    Log.d("DEBUGGUEUR=", deviceHardwareAddress.get(i - 1));
                    Log.d("DEBUGGUEUR=", devicesUuid.get(i - 1).toString());
                    Log.d("DEBUGGUEUR=", String.valueOf(i - 1));
                    try {
                        openBT(devicesUuid.get(i - 1), devicesList.get(i - 1));
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast toastFailedConnection = Toast.makeText(context, FailedConnection, duration);
                        toastFailedConnection.show();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Log.d("DEBUGGUEUR=","onNothingSelected");
            }
        });
    }
    //////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK///////////////////////////////////
    public void CreateJoystick()
    {
        JoystickView joystick1 = new JoystickView(this);
        setContentView(joystick1);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void CreateLabels()
    {
        MyReference.xValue = new TextView(this);
        MyReference.xValue.setTextColor(Color.rgb(255,255,255));
        addContentView(MyReference.xValue,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        MyReference.yValue = new TextView(this);
        MyReference.yValue.setTextColor(Color.rgb(255,255,255));
        addContentView(MyReference.yValue,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void UpdateLabels(float xPercent, float yPercent )
    {
        float X_positionxLabel = (JoystickView.centerX*2)*1/10;
        float Y_positionxLabel = (JoystickView.centerY*2)*9/10;
        float X_positionyLabel = (JoystickView.centerX*2)*5/10;
        float Y_positionyLabel = (JoystickView.centerY*2)*9/10;
        MyReference.xValue.setX(X_positionxLabel);
        MyReference.xValue.setY(Y_positionxLabel);
        MyReference.xValue.setText(Float.toString(xPercent));

        MyReference.yValue.setX(X_positionyLabel);
        MyReference.yValue.setY(Y_positionyLabel);
        MyReference.yValue.setText(Float.toString(yPercent));
    }
///////////////////////////////////BLUETOOTH METHODS///////////////////////////////////////////
    /*Bluetooth details : https://developer.android.com/guide/topics/connectivity/bluetooth#java
    *   One implementation technique is to automatically prepare each device as a server so that each device has a server socket open and listening for connections.
     */

    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void initiate_Bluetooth()
    {
        Log.d("DEBUGGUEUR=","Begin initiate_Bluetooth()");
        boolean Result=false;
        MyReference.txtBluetooth = new TextView(this);
        float Y_BluetoothLabel =0;//(JoystickView.centerY*2)*1/10;
        float X_BluetoothLabel = (JoystickView.centerX*2)*6/10;
        MyReference.txtBluetooth.setTextColor(Color.rgb(255,255,255));
        MyReference.txtBluetooth.setX(X_BluetoothLabel);
        MyReference.txtBluetooth.setY(Y_BluetoothLabel);
        addContentView(MyReference.txtBluetooth,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        MyReference.txtBluetooth.setText("Bluetooth state");
        Result=Bluetooth_Connection();
        Log.d("Bluetooth", "Result=" + Result);
        // We save the broadcast
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(bluetoothReceiver, filter);
        bluetoothAdapter.startDiscovery();
        Log.d("DEBUGGUEUR=","End initiate_Bluetooth()");
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////OK////////////////////////////////////
    public boolean Bluetooth_Connection() {
        boolean Out=false;

        if (bluetoothAdapter == null) // if object == null : the device doesn't support Bluetooth
        {
            Log.d("DEBUGGUEUR=","bluetoothAdapter==null");
            Out=false;
        }
        else        // in the case it supports Bluetooth
        {
            Out=true;
            if (!bluetoothAdapter.isEnabled()) // we are enabling the Bluetooth
            {
                Log.d("DEBUGGUEUR=","bluetoothAdapter.isEnabled()");
                //Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBlueTooth, REQUEST_CODE_ENABLE_BLUETOOTH);
                Current_State_Bluetooth(enableBlueTooth);
            }
        }
        return Out;
    }
////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////OK////////////////////////////////////
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_ENABLE_BLUETOOTH) {
            return;
        }
        if (resultCode == RESULT_OK) {
            Log.d("DEBUGGUEUR=","onActivityResult");
            // User activated Bluetooth
            devices = bluetoothAdapter.getBondedDevices();
            Log.d("DEBUGGUEUR=","getBondedDevices");
            int i=1;
            for (BluetoothDevice blueDevice : devices) {
                devicesList.add(blueDevice);
                Log.d("DEBUGGUEUR=","BluetoothDevice blueDevice");
                deviceName.add(blueDevice.getName());
                //Log.d("DEBUGGUEUR=", blueDevice.getName());
                deviceHardwareAddress.add(blueDevice.getAddress()); // MAC address
                Log.d("DEBUGGUEUR=", blueDevice.getAddress());
                devicesUuid.add(blueDevice.getUuids()[0].getUuid());
                Log.d("DEBUGGUEUR=", blueDevice.getUuids()[0].getUuid().toString());
                Log.d("DEBUGGUEUR=", String.valueOf(i));
                MyReference.bluetooth_names.add(blueDevice.getName());
                i++;
            }   // We add the paired device in the spinner
        }
        else {
            // User hasn't activated bluetooth
            MyReference.txtBluetooth.setText("Bluetooth OFF");
        }
        MyReference.spinner.setAdapter(MyReference.dataAdapter);
    }

    void openBT(UUID uuid, BluetoothDevice mDevice) throws IOException {
        Log.d("DEBUGGUEUR=","openBT");
        BluetoothSocket mSocket;
        mSocket = mDevice.createRfcommSocketToServiceRecord(uuid);
        mSocket.connect();
        mOutputStream = mSocket.getOutputStream();
        mInputStream = mSocket.getInputStream();
        boolean connection;
        connection = mSocket.isConnected();
        Context context = getApplicationContext();
        if(connection)
        {
            Toast toastConnected = Toast.makeText(context, Connected, duration);
            toastConnected.show();
            Log.d("DEBUGGUEUR=","Connected");
        }
        else{
            Toast toastNotConnected = Toast.makeText(context, NotConnected, duration);
            toastNotConnected.show();
            Log.d("DEBUGGUEUR="," NOT Connected");
        }

    }

    void sendData(String m) throws IOException{
        Log.d("DEBUGGUEUR=","sendData");
        String msg = m;
        try{
            mOutputStream.write(msg.getBytes());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////OK////////////////////////////////////////
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent)
        {
            Log.d("DEBUGGUEUR=","BroadcastReceiver bluetoothReceiver");
            String action = intent.getAction();
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                Current_State_Bluetooth(intent);
            }
        }
    };
//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////OK////////////////////////////////////////////////
    public void Current_State_Bluetooth(Intent intent) {
        Log.d("DEBUGGUEUR=", "Current_State_Bluetooth");
        float Y_BluetoothLabel = 0;
        float X_BluetoothLabel = (JoystickView.centerX * 2) * 6 / 10;
        final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                BluetoothAdapter.ERROR);
        switch (state) {
            case BluetoothAdapter.STATE_OFF:
                MyReference.txtBluetooth.setText("Bluetooth off");
                break;
            case BluetoothAdapter.STATE_TURNING_OFF:
                 MyReference.txtBluetooth.setText("Turning Bluetooth off...");
                break;
            case BluetoothAdapter.STATE_ON:
                MyReference.txtBluetooth.setText("Bluetooth on");
                break;
            case BluetoothAdapter.STATE_TURNING_ON:
                MyReference.txtBluetooth.setText("Turning Bluetooth on...");
                break;
        }
        MyReference.txtBluetooth.setX(X_BluetoothLabel);
        MyReference.txtBluetooth.setY(Y_BluetoothLabel);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////OK////////////////////////////////////////////////
    @Override
    protected void onDestroy() {
        Log.d("DEBUGGUEUR=","onDestroy");
        super.onDestroy();
        bluetoothAdapter.cancelDiscovery();
        unregisterReceiver(bluetoothReceiver);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
}