package joystick.test.joystick;

import android.bluetooth.BluetoothDevice;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.UUID;

public class MyReference {

    public static TextView xValue;
    public static TextView yValue;
    public static TextView txtBluetooth;
    public static Spinner spinner;
    public static List<String> bluetooth_names;
    public static ArrayAdapter<String> dataAdapter;

}
