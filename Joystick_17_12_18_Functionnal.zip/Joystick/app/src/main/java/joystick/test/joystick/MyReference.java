package joystick.test.joystick;

import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class MyReference {

    public static TextView xValue;
    public static TextView yValue;
    public static TextView txtBluetooth;
    public static Spinner spinner;
    public static List<String> bluetooth_names;
    public static ArrayAdapter<String> dataAdapter;
}
