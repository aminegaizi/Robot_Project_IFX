package joystick.test.joystick;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

import static java.lang.Boolean.FALSE;
import static java.lang.Math.abs;


public class main extends AppCompatActivity implements JoystickView.JoystickListener {

    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;
    private static Set<BluetoothDevice> devices;
    final BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); // Represent the device's own Bluetooth adapter
    Activity activity;
    OutputStream mOutputStream;
    InputStream mInputStream;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CreateJoystick();
        CreateLabels();
        initiate_Bluetooth();
        CreateSpinner();
    }
    
    ///////////////////////////////////////////////////////OK/////////////////////////////////////
    public void onJoystickMoved(float xPercent, float yPercent, int id)
    {
        String avancer="w";
        String reculer="s";
        String droite="d";
        String gauche="a";
        String arret="q";
        Log.d("Main Method", "X percent: " + xPercent + "Y percent: " + yPercent);
        UpdateLabels(xPercent, yPercent);
        if(abs(xPercent)>abs(yPercent))
        {
            if(xPercent>0.5)
            {
                //droite
                Log.d("onJoystickMoved : ", "droite");
                //MyReference.txtBluetooth.setText("droite");
                try {
                    sendData(droite);
                } catch (IOException e) {
                    Log.d("onJoystickMoved : ", " send failed droite");
                }
            }
            else if(xPercent<-0.5)
            {
                //gauche
                Log.d("onJoystickMoved :", "gauche");
                //MyReference.txtBluetooth.setText("gauche");
                try {
                    sendData(gauche);
                } catch (IOException e) {
                    Log.d("onJoystickMoved : ", " send failed gauche");
                }

            }

        }
        else
        {
            if(yPercent>0.5)
            {
                //avancer
                Log.d("onJoystickMoved :", "avancer");
                //MyReference.txtBluetooth.setText("avancer");
                try {
                    sendData(avancer);
                } catch (IOException e) {
                    Log.d("onJoystickMoved : ", " send failed avancer");
                }

            }
            else if(yPercent<-0.5)
            {
                //reculer
                Log.d("onJoystickMoved :", "reculer");
                //MyReference.txtBluetooth.setText("reculer");
                try {
                    sendData(reculer);
                } catch (IOException e) {
                    Log.d("onJoystickMoved : ", " send failed reculer");
                }

            }
        }
        if((xPercent==0) && (yPercent==0))
        {
            // arret
            Log.d("onJoystickMoved :", "arret");
            //MyReference.txtBluetooth.setText("arret");
            try {
                sendData(arret);
            } catch (IOException e) {
                Log.d("onJoystickMoved : ", " send failed arret");
            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void CreateSpinner()
    {
        MyReference.spinner = new Spinner(this);
        MyReference.bluetooth_names = new ArrayList<String>();
        MyReference.bluetooth_names.add("Devices available");
        MyReference.dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, MyReference.bluetooth_names);
        MyReference.dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        MyReference.spinner.setAdapter(MyReference.dataAdapter);
        MyReference.spinner.setBackgroundColor(Color.rgb(255,255,255));
        addContentView(MyReference.spinner,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
    }
    //////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK///////////////////////////////////
    public void CreateJoystick()
    {
        JoystickView joystick1 = new JoystickView(this);
        setContentView(joystick1);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void CreateLabels()
    {
        MyReference.xValue = new TextView(this);
        MyReference.xValue.setTextColor(Color.rgb(255,255,255));
        addContentView(MyReference.xValue,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        MyReference.yValue = new TextView(this);
        MyReference.yValue.setTextColor(Color.rgb(255,255,255));
        addContentView(MyReference.yValue,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void UpdateLabels(float xPercent, float yPercent )
    {
        float X_positionxLabel = (JoystickView.centerX*2)*1/10;
        float Y_positionxLabel = (JoystickView.centerY*2)*9/10;
        float X_positionyLabel = (JoystickView.centerX*2)*5/10;
        float Y_positionyLabel = (JoystickView.centerY*2)*9/10;
        MyReference.xValue.setX(X_positionxLabel);
        MyReference.xValue.setY(Y_positionxLabel);
        MyReference.xValue.setText(Float.toString(xPercent));

        MyReference.yValue.setX(X_positionyLabel);
        MyReference.yValue.setY(Y_positionyLabel);
        MyReference.yValue.setText(Float.toString(yPercent));
    }
///////////////////////////////////BLUETOOTH METHODS///////////////////////////////////////////
    /*Bluetooth details : https://developer.android.com/guide/topics/connectivity/bluetooth#java
    *   One implementation technique is to automatically prepare each device as a server so that each device has a server socket open and listening for connections.
     */

    ////////////////////////////////////////////////////////OK/////////////////////////////////////
    public void initiate_Bluetooth()
    {
        Log.d("DEBUGGUEUR=","Begin initiate_Bluetooth()");
        boolean Result=false;
        MyReference.txtBluetooth = new TextView(this);
        float Y_BluetoothLabel =0;//(JoystickView.centerY*2)*1/10;
        float X_BluetoothLabel = (JoystickView.centerX*2)*6/10;
        MyReference.txtBluetooth.setTextColor(Color.rgb(255,255,255));
        MyReference.txtBluetooth.setX(X_BluetoothLabel);
        MyReference.txtBluetooth.setY(Y_BluetoothLabel);
        addContentView(MyReference.txtBluetooth,
                new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        MyReference.txtBluetooth.setText("Bluetooth state");
        Result=Bluetooth_Connection();
        Log.d("Bluetooth", "Result=" + Result);
        // We save the broadcast
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(bluetoothReceiver, filter);
        bluetoothAdapter.startDiscovery();
        Log.d("DEBUGGUEUR=","End initiate_Bluetooth()");
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////OK////////////////////////////////////
    public boolean Bluetooth_Connection() {
        boolean Out=false;

        if (bluetoothAdapter == null) // if object == null : the device doesn't support Bluetooth
        {
            Log.d("DEBUGGUEUR=","bluetoothAdapter==null");
            Out=false;
        }
        else        // in the case it supports Bluetooth
        {
            Out=true;
            if (!bluetoothAdapter.isEnabled()) // we are enabling the Bluetooth
            {
                Log.d("DEBUGGUEUR=","bluetoothAdapter.isEnabled()");
                Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBlueTooth, REQUEST_CODE_ENABLE_BLUETOOTH);
                Current_State_Bluetooth(enableBlueTooth);
            }
        }
        return Out;
    }
////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////OK////////////////////////////////////
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_ENABLE_BLUETOOTH) {
            return;
        }
        if (resultCode == RESULT_OK) {
            // L'utilisateur a activé le bluetooth
            //MyReference.txtBluetooth.setText("Bluetooth ON");
            devices = bluetoothAdapter.getBondedDevices();
            for (BluetoothDevice blueDevice : devices) {
                Log.d("DEBUGGUEUR=","onActivityResult");
                String deviceName = blueDevice.getName();
                String deviceHardwareAddress = blueDevice.getAddress(); // MAC address
                MyReference.bluetooth_names.add(deviceName);
               //if(deviceName=="HC-05")
                {
                    UUID uuid_HC05=blueDevice.getUuids()[0].getUuid();
                    try {
                        openBT(uuid_HC05, blueDevice);
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.d("DEBUGGUEUR=","failed in openBT");
                    }


                }

            }   // On ajoute les appareils avec lesquels on est déjà appairé.
        }
        else {
            // L'utilisateur n'a pas activé le bluetooth
            //MyReference.txtBluetooth.setText("Bluetooth OFF");
        }
        MyReference.spinner.setAdapter(MyReference.dataAdapter);
    }

    void openBT(UUID uuid, BluetoothDevice mDevice) throws IOException {
        Log.d("DEBUGGUEUR=","openBT");
        BluetoothSocket mSocket;
        //uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"); //Standard SerialPortService ID
        Log.d("DEBUGGUEUR=","1");
        mSocket = mDevice.createRfcommSocketToServiceRecord(uuid);
        Log.d("DEBUGGUEUR=","2");
        mSocket.connect();
        Log.d("DEBUGGUEUR=","3");
        mOutputStream = mSocket.getOutputStream();
        mInputStream = mSocket.getInputStream();
        boolean connection;
        Log.d("DEBUGGUEUR=","4");
        connection = mSocket.isConnected();
        if(connection)
        {
            Log.d("DEBUGGUEUR=","Connected");
        }
        else{
            Log.d("DEBUGGUEUR="," NOT Connected");
        }

    }

    void sendData(String m) throws IOException{
        Log.d("DEBUGGUEUR=","sendData");
        String msg = m;
        mOutputStream.write(msg.getBytes());
    }
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////OK////////////////////////////////////////
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent)
        {
            Log.d("DEBUGGUEUR=","BroadcastReceiver bluetoothReceiver");
            String action = intent.getAction();
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                Current_State_Bluetooth(intent);
            }
        }
    };
//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////OK////////////////////////////////////////////////
    public void Current_State_Bluetooth(Intent intent) {
        Log.d("DEBUGGUEUR=", "Current_State_Bluetooth");
        float Y_BluetoothLabel = 0;
        float X_BluetoothLabel = (JoystickView.centerX * 2) * 6 / 10;
        final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                BluetoothAdapter.ERROR);
        switch (state) {
            case BluetoothAdapter.STATE_OFF:
                MyReference.txtBluetooth.setText("Bluetooth off");
                break;
            case BluetoothAdapter.STATE_TURNING_OFF:
                // MyReference.txtBluetooth.setText("Turning Bluetooth off...");
                break;
            case BluetoothAdapter.STATE_ON:
                MyReference.txtBluetooth.setText("Bluetooth on");
                break;
            case BluetoothAdapter.STATE_TURNING_ON:
                MyReference.txtBluetooth.setText("Turning Bluetooth on...");
                break;
        }
        MyReference.txtBluetooth.setX(X_BluetoothLabel);
        MyReference.txtBluetooth.setY(Y_BluetoothLabel);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////OK////////////////////////////////////////////////
    @Override
    protected void onDestroy() {
        Log.d("DEBUGGUEUR=","onDestroy");
        super.onDestroy();
        bluetoothAdapter.cancelDiscovery();
        unregisterReceiver(bluetoothReceiver);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
}