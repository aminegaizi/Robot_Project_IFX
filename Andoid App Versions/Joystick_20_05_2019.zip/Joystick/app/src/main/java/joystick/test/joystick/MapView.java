package joystick.test.joystick;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;


public class MapView extends View {
    private Paint paint=new Paint();
    private Paint paintRobot = new Paint();
    private Paint paintText = new Paint();
    private Paint paintCircle = new Paint();
    private static float rectLeft=0.0f;
    private static float rectTop=0.0f;
    private static float rectRight=1.0f;
    private static float rectBottom=1.0f;
    private static float rectangleWidth=10;
    float[] cx={50, 150, 250,350, 450,550,650};
    float[] cy={50, 50,50, 50, 50, 50, 50,};
    float[] robotPosition= {550, 800, 650, 900};
    public int iZones=1;
    protected float[][] allZones = new float[49][3]; //[Zone 1,X_Middle1, Y_Middle1] [Zone 2, X_Middle2, Y_Middle2] [Zone 3, X_Middle2, Y_Middle2]......
    private int nbLines=1;
    private int nbRows=1;
    public boolean freezeTouch=false;
    Context context;


    public MapView(Context context) {
        super(context);
        init();
        this.context=context;
    }

    public MapView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
        this.context=context;
    }

    public MapView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
        this.context=context;
    }

    private void init(){
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStrokeWidth(rectangleWidth);
        paint.setStyle(Paint.Style.STROKE);

        paintRobot = new Paint();
        paintRobot.setColor(Color.RED);
        //paintRobot.setStrokeWidth(10);
        //paintRobot.setStyle(Paint.Style.STROKE);
        paintText = new Paint();
        paintText.setColor(Color.BLUE);
        paintText.setTextSize(40);

        paintCircle = new Paint();
        paintCircle.setColor(Color.YELLOW);
        paintCircle.setStrokeWidth(10);

    }

    private void setupDimensions()
    {
        rectLeft = rectangleWidth/2;
        rectTop = rectangleWidth/2;
        rectRight = (float)getWidth()-(rectangleWidth/2) ;
        rectBottom = rectRight;
    }


    @Override
    protected void onDraw(Canvas canvas) {
        /*int cx1=50, cx2=105, cx3=160, cx4=215, cx5=270, cxS=325, cxE=380;
        int cy1=50, cy2=50, cy3=50, cy4=50, cy5=50, cyS=50, cyE=50;
        int leftRobot=50, topRobot=150, rightRobot=150, bottomRobot=250;*/

        super.onDraw(canvas);
        setupDimensions();
        DrawMap(canvas, cx, cy,  robotPosition);

    }

    public void DrawMap(Canvas canvas, float cx[], float cy[], float robotPosition[]){
        int radius=25;
        int offsetX=10;
        int offsetY=15;
        canvas.drawRect(rectLeft, rectTop, rectRight, rectBottom, paint);
        canvas.drawCircle(cx[1], cy[1], radius, paint);
        canvas.drawText("1", cx[1]-offsetX, cy[1]+offsetY, paintText);
        canvas.drawCircle(cx[2],cy[2],radius, paint);
        canvas.drawText("2", cx[2]-offsetX, cy[2]+offsetY, paintText);
        canvas.drawCircle(cx[3],cy[3],radius, paint);
        canvas.drawText("3", cx[3]-offsetX, cy[3]+offsetY, paintText);
        canvas.drawCircle(cx[4],cy[4],radius, paint);
        canvas.drawText("4", cx[4]-offsetX, cy[4]+offsetY, paintText);
        canvas.drawCircle(cx[5],cy[5],radius, paint);
        canvas.drawText("5", cx[5]-offsetX, cy[5]+offsetY, paintText);
        canvas.drawCircle(cx[6],cy[6],radius, paint);
        canvas.drawText("S", cx[6]-offsetX, cy[6]+offsetY, paintText);
        canvas.drawCircle(cx[0],cy[0],radius, paint);
        canvas.drawText("E", cx[0]-offsetX, cy[0]+offsetY, paintText);
        canvas.drawRect(robotPosition[0],robotPosition[1],robotPosition[2],robotPosition[3],paintRobot);
        if(iZones!=1){
            for (int i = 1; i <= nbLines; i++) {
                canvas.drawLine(rectRight, ((rectBottom - rectTop) / nbLines * i), rectLeft, ((rectBottom - rectTop) / nbLines * i), paint);

            }
            for (int i = 1; i <= nbRows; i++) {
                canvas.drawLine(((rectRight - rectLeft) / nbRows * i), rectTop, ((rectRight - rectLeft) / nbRows * i), rectBottom, paint);
            }

            int k=1;
            int f=1;
            for(int i=0; i<iZones; i++) {
                //Log.d("DEBUGGER=", "Zones, X, Y");
                allZones[i][0] = i + 1;  // Zone
                //Log.d("DEBUGGER=", "Zones:");
                //Log.d("DEBUGGER=", String.valueOf(allZones[i][0]));

                if(i<nbRows){ // X
                    //allZones[i][1] = f;
                    allZones[i][1] = ((rectRight - rectLeft) / nbRows * f ) - (rectRight - rectLeft) / nbRows / 2; // X (middle of the zone)
                    f=f+1;
                }
                else{
                    //allZones[i][1] = allZones[i-nbRows][1];
                    allZones[i][1] = allZones[i-nbRows][1]; // ((rectRight - rectLeft) / nbRows * f ) - (rectRight - rectLeft) / nbRows / 2; // X (middle of the zone)
                }

                if(i==0) { // Y
                   // allZones[i][2] = k;
                    allZones[i][2] = ((rectBottom - rectTop) / nbLines * k) - (rectBottom - rectTop) / nbLines / 2; // Y (middle of the zone)
                }
                else if(nbRows*k==i){
                    k=k+1;
                    //allZones[i][2] = k;
                    allZones[i][2] = ((rectBottom - rectTop) / nbLines * k) - (rectBottom - rectTop) / nbLines / 2; // Y (middle of the zone)

                }
                else{
                    //allZones[i][2] = k;
                    allZones[i][2] = ((rectBottom - rectTop) / nbLines * k) - (rectBottom - rectTop) / nbLines / 2; // Y (middle of the zone)
                }
                /*Log.d("DEBUGGER=", "X:");
                Log.d("DEBUGGER=", String.valueOf(allZones[i][1]));
                Log.d("DEBUGGER=", "Y:");
                Log.d("DEBUGGER=", String.valueOf(allZones[i][2]));*/
                //canvas.drawCircle(allZones[i][1], allZones[i][2], radius, paintCircle);
            }
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
            //joystick.test.joystick.MapView myCanvas = findViewById(R.id.mapView);
            float X = event.getX();
            float Y = event.getY();
            if(!freezeTouch) {
                if ((X > 50 && X < getWidth() - 50) && (Y > 50 && Y < rectBottom - 50)) {
                    robotPosition[0] = X - 50;
                    robotPosition[1] = Y - 50;
                    robotPosition[2] = X + 50;
                    robotPosition[3] = Y + 50;
                    ZoneRobot(X,Y);
                    invalidate();
                }
            }
        return super.onTouchEvent(event);
    }

    private String ZoneRobot(float XRobot, float YRobot){
        String sZone="";
        float[] X={0,0};
        float[] Y={0,0};
        boolean t=false;
        int i=0;
        X[1] = allZones[i+1][1];
        while(i<nbRows) {       // Find corresponding X of Zone
            X[0] = allZones[i][1];

            if(Math.abs(XRobot-X[0])<=Math.abs(XRobot-X[1])){
                X[1] = X[0];
            }
            i++;
        }
        XRobot=X[1];
        Log.d("DEBUGGER=", "New XRobot="+XRobot);
        i=0;
        Y[1] = allZones[i+1][2];
        while(i<nbLines*nbRows) {      // Find corresponding Y of Zone
            Y[0] = allZones[i][2];
            if(Math.abs(YRobot-Y[0])<=Math.abs(YRobot-Y[1])){
                Y[1] = Y[0];
            }
            i++;
        }
        YRobot=Y[1];
        Log.d("DEBUGGER=", "New YRobot="+YRobot);

        for ( int k = 0; k < nbLines*nbRows; k++ ) {
            if ( allZones[k][1] == XRobot && allZones[k][2] == YRobot) {
                Log.d("DEBUGGER=", "ZONE="+allZones[k][0]);
                sZone = "Zone " + (int)allZones[k][0];
            }
        }
        TextView textZoneRobot = ((Activity)context).findViewById(R.id.zoneRobot);
        textZoneRobot.setText(sZone);
        return sZone;
    }

    public void AddZones(int iLines, int iRows){
        iZones=iLines*iRows;
        nbLines=iLines;
        nbRows=iRows;
        invalidate();
    }
}
