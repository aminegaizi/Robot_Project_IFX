package joystick.test.joystick;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

// for real-time debugging with USB in the Logcat (Android Studio)

public class main extends AppCompatActivity implements JoystickView.JoystickListener {

    // bluetooth variables
    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;
    final BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); // Represent the device's own Bluetooth adapter
    BluetoothSocket mSocket;
    OutputStream mOutputStream;
    InputStream mInputStream;
    Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
    ArrayList<String> deviceName = new ArrayList<>();
    ArrayList<String> deviceHardwareAddress = new ArrayList<>();
    ArrayList<UUID> devicesUuid = new ArrayList<>();
    ArrayList<BluetoothDevice> devicesList = new ArrayList<>();
    CharSequence Connection = "Connecting...";
    CharSequence FailedConnection = "Failed to Connect";
    CharSequence Connected = "Connected";
    CharSequence NotConnected = "Not connected";
    int duration = Toast.LENGTH_SHORT;
    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    volatile boolean stopWorker;
    boolean buttonONOFF_Mode2_State=false;
    boolean buttonONOFF_Mode3_State=false;
    String Current_Move="";
    String Previous_Move="";
    String Tab1="Tab One";
    String Tab2="Tab Two";
    String Tab3="Tab Three";
    String[] ButtonONOFF={"ON","OFF"};
    boolean connected;
    // Text boxes Texts
    public  TextView xValue;
    public  TextView yValue;
    public  TextView textDistanceFromObstacle;
    public  TextView distanceFromObstacle;
    public  TextView textRightEncoder;
    public  TextView rightEncoder;
    public  TextView textLeftEncoder;
    public  TextView leftEncoder;
    public  TextView textxPosition;
    public  TextView xPosition;
    public  TextView textyPosition;
    public  TextView yPosition;
    public  TextView textRobotOrientation;
    public  TextView robotOrientation;
    public  TextView txtBluetooth;
    public TextView textZoneRobot;

    public  Spinner spinner;
    public static List<String> bluetooth_names;
    public static ArrayAdapter<String> dataAdapter;
    public  Button buttonON_OFF_mode2;
    public  Button buttonON_OFF_mode3;
    public static JoystickView joystick1;

    public static MapView mapView;

    LinearLayout line1, line2, line3, line4, line5, map, lineFill, PlusMinus;

    public int iLines=1;
    public int iRows=1;


    @Override
    /* public void onCreate(Bundle savedInstanceState) : When App is launched, this is the first function called.
     *   It creates all the objects needed :
     *   the joystick, the labels, the buttons, the spinner and initiate the bluetooth
     */
    public void onCreate(Bundle savedInstanceState)  {
        //Log.d("DEBUGGER=","onCreate()"); // for real-time debbuging with USB in the Logcat (Android Studio)
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CreateModeScreens();
        CreateSpinner();
        CreateJoystick();
        CreateLabels();
        CreateButtons();
        initiate_Bluetooth();
        //DrawButton();
        mapView = findViewById(R.id.mapView);
        textZoneRobot = findViewById(R.id.zoneRobot);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    public void CreateModeScreens(){

        final TabHost host = findViewById(R.id.tabHost);
        host.setup();
        line1= findViewById(R.id.line1);
        line2=findViewById(R.id.line2);
        line3= findViewById(R.id.line3);
        line4= findViewById(R.id.line4);
        line5= findViewById(R.id.line5);
        map= findViewById(R.id.map);
        lineFill= findViewById(R.id.lineFill);
        PlusMinus= findViewById(R.id.PlusMinus);

        //Tab 1
        TabHost.TabSpec spec = host.newTabSpec(Tab1);
        spec.setContent(R.id.mode1);
        spec.setIndicator("Mode 1");
        host.addTab(spec);


        //Tab 2
        spec = host.newTabSpec(Tab2);
        spec.setContent(R.id.mode2);
        spec.setIndicator("Mode 2");
        host.addTab(spec);

        //Tab 3
        spec = host.newTabSpec(Tab3);
        spec.setContent(R.id.mode3);
        spec.setIndicator("Mode 3");
        host.addTab(spec);

        line1.setVisibility(View.VISIBLE);
        line2.setVisibility(View.VISIBLE);
        line3.setVisibility(View.VISIBLE);
        line4.setVisibility(View.VISIBLE);
        line5.setVisibility(View.VISIBLE);
        map.setVisibility(View.GONE);
        PlusMinus.setVisibility(View.GONE);
        lineFill.setVisibility(View.VISIBLE);

        host.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if(tabId.equals(Tab1)){
                    if(connected){ModeSelection("1");}
                    line1.setVisibility(View.VISIBLE);
                    line2.setVisibility(View.VISIBLE);
                    line3.setVisibility(View.VISIBLE);
                    line4.setVisibility(View.VISIBLE);
                    line5.setVisibility(View.VISIBLE);
                    map.setVisibility(View.GONE);
                    PlusMinus.setVisibility(View.GONE);
                    lineFill.setVisibility(View.VISIBLE);
                }
                else if (tabId.equals(Tab2)){
                    if(connected){ModeSelection("2");}
                    line1.setVisibility(View.VISIBLE);
                    line2.setVisibility(View.VISIBLE);
                    line3.setVisibility(View.VISIBLE);
                    line4.setVisibility(View.VISIBLE);
                    line5.setVisibility(View.VISIBLE);
                    map.setVisibility(View.GONE);
                    PlusMinus.setVisibility(View.GONE);
                    lineFill.setVisibility(View.VISIBLE);

                }
                else if (tabId.equals(Tab3)){
                    if(connected){ModeSelection("3");}
                    line1.setVisibility(View.GONE);
                    line2.setVisibility(View.GONE);
                    line3.setVisibility(View.GONE);
                    line4.setVisibility(View.GONE);
                    line5.setVisibility(View.GONE);
                    map.setVisibility(View.VISIBLE);
                    PlusMinus.setVisibility(View.VISIBLE);
                    lineFill.setVisibility(View.GONE);
                }
                if(!tabId.equals(Tab2)){
                    buttonON_OFF_mode2.setText(ButtonONOFF[0]);
                    buttonON_OFF_mode2.setBackgroundColor(Color.rgb(150, 150, 150));
                }
                if(!tabId.equals(Tab3)){
                    buttonON_OFF_mode3.setText(ButtonONOFF[0]);
                    buttonON_OFF_mode3.setBackgroundColor(Color.rgb(150, 150, 150));
                    mapView.freezeTouch=false;
                }
            }
        });
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    /* public void onJoystickMoved(float xPercent, float yPercent, int id) : function that depends on Joystick Listener
     *  This function sends a string depending to the joystick position
     *  stop="q"  straight = "w"    back = "s"  right = "d" left = "a"  straightLeft = "e"  straightRight = "r"
     *  backLeft = "f"  backRight = "g";
     */
    ///////////////////////////////////////////////////////////////////////////////////////////
    public void onJoystickMoved(float xPercent, float yPercent, int id) {
        //Nine types of string can be send :
        String straight = "w";
        String back = "s";
        String right = "d";
        String left = "a";
        String stop = "q";
        String straightLeft = "e";
        String straightRight = "r";
        String backLeft = "f";
        String backRight = "g";
        UpdateLabels(xPercent, yPercent);
        if(connected) {
            // Decompose in 9 positions : center-right-left-up-down-backRight-backLeft-straightRight-straightLeft
            if (xPercent > 0.85) {
                // right
                Current_Move = "right";

            } else if (xPercent < -0.85) {
                //left
                Current_Move = "left";

            } else if (yPercent > 0.85) {
                //go straight
                Current_Move = "straight";
            } else if (yPercent < -0.85) {
                //go back
                Current_Move = "back";

            } else if ((xPercent == 0) && (yPercent == 0)) {
                // stop
                Current_Move = "stop";
            } else if ((xPercent > 0.65 && xPercent < 0.85) && (yPercent < -0.35 && yPercent > -0.85)) {
                //backRight
                Current_Move = "backRight";

            } else if ((xPercent < -0.65 && xPercent > -0.85) && (yPercent < -0.35 && yPercent > -0.85)) {
                //backLeft
                Current_Move = "backLeft";

            } else if ((xPercent > 0.65 && xPercent < 0.85) && (yPercent > 0.35 && yPercent < 0.85)) {
                //straightRight
                Current_Move = "straightRight";

            } else if ((xPercent < -0.65 && xPercent > -0.85) && (yPercent > 0.35 && yPercent < 0.85)) {
                //straightLeft
                Current_Move = "straightLeft";
            }

            if (!Current_Move.equals(Previous_Move)) {
                //Log.d("onJoystickMoved :", Current_Move); // for real-time debbuging with USB in the Logcat (Android Studio)
                switch (Current_Move) {
                    case "right":
                        try {
                            sendData(right);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "left":
                        try {
                            sendData(left);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "straight":
                        try {
                            sendData(straight);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "back":
                        try {
                            sendData(back);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "stop":
                        try {
                            sendData(stop);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "backRight":
                        try {
                            sendData(backRight);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "backLeft":
                        try {
                            sendData(backLeft);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "straightRight":
                        try {
                            sendData(straightRight);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case "straightLeft":
                        try {
                            sendData(straightLeft);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                }

                Previous_Move = Current_Move;
            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    /* public void CreateSpinner() : create the spinner object + initialize its parameters
     * Contains its listener onItemSelected for creating a socket when bluetooth connection is requested
     */
    public void CreateSpinner() {
        spinner= findViewById(R.id.spinner);
        bluetooth_names = new ArrayList<>();
        bluetooth_names.add("Devices available");
        dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, bluetooth_names);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setBackgroundColor(Color.rgb(255, 255, 255));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i != 0) {
                    if (bluetooth_names.get(i).equals("DISCONNECT")) {
                        // If the user clicks on disconnect button, socket is closed and button disconnect removed
                        try {
                            mSocket.close();
                            bluetooth_names.remove("DISCONNECT");
                            connected=false;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        // The user has selected an item for a bluetooth connection.
                        Context context = getApplicationContext();
                        Toast toastConnection = Toast.makeText(context, Connection, duration);
                        toastConnection.show();
                        try {
                            openBT(devicesUuid.get(i - 1), devicesList.get(i - 1)); // Call the function for opening bluetooth socket
                            connected=true;

                        } catch (IOException e) {
                            e.printStackTrace();
                            Toast toastFailedConnection = Toast.makeText(context, FailedConnection, duration);
                            toastFailedConnection.show();
                            connected=false;
                        }
                    }
                }
            }

            // If user doesn't select anything in the Spinner
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Log.d("DEBUGGER=", "onNothingSelected"); // for real-time debbuging with USB in the Logcat (Android Studio)
            }
        });
    }

    //////////////////////////////////////////////////////////////////////////////////////////////
    // public void CreateJoystick() : create the Joystick object and add it in the View
    public void CreateJoystick() {
        joystick1= findViewById(R.id.joystick);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /* public void CreateLabels() : instantiate the different labels and determine their parameters
     * Position of textBoxes managed in the layout (activity_main.xml)
     */
    public void CreateLabels() {
        String[] XYText={"0.0", "0.0"};
        String[] textBoxes={"Bluetooth State","Distance from obstacle :", "N/A", "Right encoder :", "N/A", "Left encoder :", "N/A", "X Position(cm):", "N/A", "Y Position(cm):", "N/A", "Orientation (°) :","N/A"};
        // Label for Bluetooth state (connected/not connected/connecting...)
        txtBluetooth=findViewById(R.id.txtBluetooth);
        txtBluetooth.setTextColor(Color.rgb(255, 255, 255));
        txtBluetooth.setText(textBoxes[0]);
        //Labels for x and y value of the joystick
        // Joystick X Value
        xValue=findViewById(R.id.xValue);
        xValue.setTextColor(Color.rgb(255, 255, 255));
        xValue.setText(XYText[0]);
        // Joystick Y Value
        yValue=findViewById(R.id.yValue);
        yValue.setTextColor(Color.rgb(255, 255, 255));
        yValue.setText(XYText[1]);

        //Labels for data sent by robot
        //object to store display information
        textDistanceFromObstacle=findViewById(R.id.textDistanceFromObstacle);
        textDistanceFromObstacle.setTextColor(Color.rgb(255, 255, 255));
        textDistanceFromObstacle.setText(textBoxes[1]);
        // BE CAREFUL : (JoystickView.centerX*2)== metrics.widthPixels (width of the screen) BUT (JoystickView.centerY*2)!= metrics.heightPixels !!!
        // The first one considers the layout screen whereas the 2nd one considers all the screen.
        distanceFromObstacle=findViewById(R.id.distanceFromObstacle);
        distanceFromObstacle.setTextColor(Color.rgb(255, 255, 255));
        distanceFromObstacle.setText(textBoxes[2]);

        textRightEncoder=findViewById(R.id.textRightEncoder);
        textRightEncoder.setTextColor(Color.rgb(255, 255, 255));
        textRightEncoder.setText(textBoxes[3]);

        rightEncoder=findViewById(R.id.rightEncoder);
        rightEncoder.setTextColor(Color.rgb(255, 255, 255));
        rightEncoder.setText(textBoxes[4]);

        textLeftEncoder=findViewById(R.id.textLeftEncoder);
        textLeftEncoder.setTextColor(Color.rgb(255, 255, 255));
        textLeftEncoder.setText(textBoxes[5]);

        leftEncoder=findViewById(R.id.leftEncoder);
        leftEncoder.setTextColor(Color.rgb(255, 255, 255));
        leftEncoder.setText(textBoxes[6]);

        textxPosition=findViewById(R.id.textxPosition);
        textxPosition.setTextColor(Color.rgb(255, 255, 255));
        textxPosition.setText(textBoxes[7]);

        xPosition=findViewById(R.id.xPosition);
        xPosition.setTextColor(Color.rgb(255, 255, 255));
        xPosition.setText(textBoxes[8]);

        textyPosition=findViewById(R.id.textyPosition);
        textyPosition.setTextColor(Color.rgb(255, 255, 255));
        textyPosition.setText(textBoxes[9]);

        yPosition=findViewById(R.id.yPosition);
        yPosition.setTextColor(Color.rgb(255, 255, 255));
        yPosition.setText(textBoxes[10]);

        textRobotOrientation=findViewById(R.id.textRobotOrientation);
        textRobotOrientation.setTextColor(Color.rgb(255, 255, 255));
        textRobotOrientation.setText(textBoxes[11]);

        robotOrientation=findViewById(R.id.robotOrientation);
        robotOrientation.setTextColor(Color.rgb(255, 255, 255));
        robotOrientation.setText(textBoxes[12]);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /*  public void CreateButtons() : create 3 buttons to chose Mode 1 - 2 or 3
     *  When a mode is selected, button to corresponding mode is green, others are grey.
     *  Mode 1 is selected by default
     *  The listener of each button is created here. When a button is clicked :
     *  Color of buttons is changed. A string is sent to the robot to give the current mode ("1", "2", "3")
     */
    public void CreateButtons() {
        final String[] ONOFF={"ON", "OFF"};
//        Log.d("DEBUGGER=","CreateButtons()");

        Button buttonPlusLine = findViewById(R.id.ButtonPlusLine);
        Button buttonMinusLine = findViewById(R.id.ButtonMinusLine);
        Button buttonPlusRow = findViewById(R.id.ButtonPlusRow);
        Button buttonMinusRow = findViewById(R.id.ButtonMinusRow);

//        Log.d("DEBUGGER=","find ViewById Done");

        final TextView NbLines = findViewById(R.id.NbLines);
        final TextView NbRows = findViewById(R.id.NbRows);



        buttonPlusLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("DEBUGGER="," buttonPlusLine.setOnClickListener");
                if(iLines<7){
                    iLines++;
                    NbLines.setText(String.valueOf(iLines));
                    mapView.AddZones(iLines, iRows);
                }
            }
        });

        buttonMinusLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("DEBUGGER="," buttonMinusLine.setOnClickListener");
                if(iLines>1){
                    iLines--;
                    NbLines.setText(String.valueOf(iLines));
                    mapView.AddZones(iLines, iRows);
                }
            }
        });

        buttonPlusRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("DEBUGGER="," buttonPlusRow.setOnClickListener");
                if(iRows<7){
                    iRows++;
                    NbRows.setText(String.valueOf(iRows));
                    mapView.AddZones(iLines, iRows);
                }
            }
        });

        buttonMinusRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("DEBUGGER="," buttonMinusRow.setOnClickListener");
                if (iRows > 1) {
                    iRows--;
                    NbRows.setText(String.valueOf(iRows));
                    mapView.AddZones(iLines, iRows);
                }
            }
        });

                // Get the dimensions and place the button mode 2 + determine parameters + listener
        buttonON_OFF_mode2=findViewById(R.id.buttonONOFFmode2);
        buttonON_OFF_mode2.setTextColor(Color.rgb(255, 255, 255));
        buttonON_OFF_mode2.setBackgroundColor(Color.rgb(150, 150, 150));
        buttonON_OFF_mode2.setText(ONOFF[0]);
        ///////////////setOnClickListener//////////////////////////
        buttonON_OFF_mode2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if(buttonONOFF_Mode2_State){
                    buttonONOFF_Mode2_State=false;
                    buttonON_OFF_mode2.setText(ONOFF[0]);
                    buttonON_OFF_mode2.setBackgroundColor(Color.rgb(150, 150, 150));
                    if(connected) {
                        try {
                            sendData("q");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                else{
                    buttonONOFF_Mode2_State=true;
                    buttonON_OFF_mode2.setText(ONOFF[1]);
                    buttonON_OFF_mode2.setBackgroundColor(Color.rgb(0, 255, 0));
                    if(connected) {
                        try {
                            sendData("v");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        // Get the dimensions and place the button mode 3 + determine parameters + listener
        buttonON_OFF_mode3=findViewById(R.id.buttonONOFFmode3);
        buttonON_OFF_mode3.setTextColor(Color.rgb(255, 255, 255));
        buttonON_OFF_mode3.setBackgroundColor(Color.rgb(150, 150, 150));
        buttonON_OFF_mode3.setText(ONOFF[0]);
        ///////////////setOnClickListener//////////////////////////
        buttonON_OFF_mode3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mapView.freezeTouch=!mapView.freezeTouch;
                if(buttonONOFF_Mode3_State){
                    buttonONOFF_Mode3_State=false;
                    buttonON_OFF_mode3.setText(ONOFF[0]);
                    buttonON_OFF_mode3.setBackgroundColor(Color.rgb(150, 150, 150));
                    if(connected) {
                        try {
                            sendData("q");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                else{
                    buttonONOFF_Mode3_State=true;
                    buttonON_OFF_mode3.setText(ONOFF[1]);
                    buttonON_OFF_mode3.setBackgroundColor(Color.rgb(0, 255, 0));
                    if(connected) {
                        try {
                            sendData("v");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // ModeSelection(String sMode): Function that sends the mode selected. Used by the buttons listeners (just over in CreateButtons)
    public void ModeSelection(String sMode){
        try {
            sendData(sMode);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Update the value of the Joystick position label.
    public void UpdateLabels(float xPercent, float yPercent )
    {
        xValue.setText(String.valueOf(xPercent));
        yValue.setText(String.valueOf(yPercent));

    }
///////////////////////////////////BLUETOOTH METHODS///////////////////////////////////////////
    /*Bluetooth details : https://developer.android.com/guide/topics/connectivity/bluetooth#java
     *  One implementation technique is to automatically prepare each device as a server so that each device has a server socket open and listening for connections.
     *  Function initiate_Bluetooth() : check if bluetooth is existing on the phone.
     */
    /////////////////////////////////////////////////////////////////////////////////////////////
    public void initiate_Bluetooth()
    {
        boolean Result;
        Result=Bluetooth_Connection(); // We can use Result to show if Bluetooth exists on the device
        if(!Result){
            String text="No Bluetooth available on this phone";
            txtBluetooth.setText(text);
        }
        else {
            // We save the broadcast
            IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(bluetoothReceiver, filter);
            bluetoothAdapter.startDiscovery();
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////OK////////////////////////////////////
    // Bluetooth_Connection() :  turns bluetooth on. (Requires user's acceptation.)
    public boolean Bluetooth_Connection() {
        boolean Out;

        if (bluetoothAdapter == null) // if object == null : the device doesn't support Bluetooth
        {
            //Log.d("DEBUGGER=","bluetoothAdapter==null"); // for real-time debbuging with USB in the Logcat (Android Studio)
            Out=false;
        }
        else        // in the case it supports Bluetooth
        {
            Out=true;
            if (!bluetoothAdapter.isEnabled()) // we are enabling the Bluetooth
            {
                //Log.d("DEBUGGER=","bluetoothAdapter.isEnabled()"); // for real-time debbuging with USB in the Logcat (Android Studio)
                //Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBlueTooth, REQUEST_CODE_ENABLE_BLUETOOTH);
                Current_State_Bluetooth(enableBlueTooth);
            }
        }
        return Out;
    }
////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////OK////////////////////////////////////
    // Function onActivityResult(): list the  bluetooth devices available in the spinner.
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Set<BluetoothDevice> devices;
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_ENABLE_BLUETOOTH) {
            return;
        }
        if (resultCode == RESULT_OK) {
            //Log.d("DEBUGGER=","onActivityResult"); // for real-time debbuging with USB in the Logcat (Android Studio)
            // User activated Bluetooth
            devices = bluetoothAdapter.getBondedDevices();
            //Log.d("DEBUGGER=","getBondedDevices"); // for real-time debbuging with USB in the Logcat (Android Studio)
            for (BluetoothDevice blueDevice : devices) {
                devicesList.add(blueDevice);
                //Log.d("DEBUGGER=","BluetoothDevice blueDevice"); // for real-time debbuging with USB in the Logcat (Android Studio)
                deviceName.add(blueDevice.getName());
                deviceHardwareAddress.add(blueDevice.getAddress());
                devicesUuid.add(blueDevice.getUuids()[0].getUuid());
                bluetooth_names.add(blueDevice.getName());
            }   // We add the paired device in the spinner
        }
        else {
            // User hasn't activated bluetooth
            String textOff = "Bluetooth OFF";
            txtBluetooth.setText(textOff);
        }
        spinner.setAdapter(dataAdapter);
    }

    /*  Function openBT() : when a device is selected for connection,
     *  open the socket.
     *  Also used to disconnect bluetooth.
     */
    void openBT(UUID uuid, BluetoothDevice mDevice) throws IOException {
        //Log.d("DEBUGGER=","openBT"); // for real-time debbuging with USB in the Logcat (Android Studio)
        mSocket = mDevice.createRfcommSocketToServiceRecord(uuid);
        mSocket.connect();
        mOutputStream = mSocket.getOutputStream();
        mInputStream = mSocket.getInputStream();
        boolean connection;
        connection = mSocket.isConnected();
        Context context = getApplicationContext();
        if(connection)
        {
            Toast toastConnected = Toast.makeText(context, Connected, duration);
            toastConnected.show();
            //Log.d("DEBUGGER=","Connected"); // for real-time debbuging with USB in the Logcat (Android Studio)
            bluetooth_names.add("DISCONNECT");
            spinner.setAdapter(dataAdapter);
            beginListenForData();
            ModeSelection("1");
        }
        else{
            Toast toastNotConnected = Toast.makeText(context, NotConnected, duration);
            toastNotConnected.show();
            //Log.d("DEBUGGER="," NOT Connected"); // for real-time debbuging with USB in the Logcat (Android Studio)
        }
    }

    //  Function sendData() : writes the string to send in the bluetooth socket.
    void sendData(String m) throws IOException {
        //Log.d("DEBUGGER=","sendData = "+m); // for real-time debbuging with USB in the Logcat (Android Studio)
        mOutputStream.write(m.getBytes());
        //Log.d("DEBUGGER=","OK"); // for real-time debbuging with USB in the Logcat (Android Studio)
    }
    /*
     *  Function beginListenForData()
     *  Aim : getting the entering Bluetooth data from the robot sensors and
     *  display them on the TextViews.
     *  Char received :   a=97  b=98    c=99  t=116   x=120   y=121   space=32
     *
     */
    void beginListenForData()
    {
        //Log.d("DEBUGGER="," beginListenForData"); // for real-time debbuging with USB in the Logcat (Android Studio)
        //final Handler handler = new Handler();
        //final byte delimiter = 10; //This is the ASCII code for a newline character
        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];
        workerThread = new Thread(new Runnable()
        {
            public void run()
            { // New Thread is created
                while(!Thread.currentThread().isInterrupted() && !stopWorker)
                {
                    try // We get the Bluetooth input stream
                    {
                        int bytesAvailable = mInputStream.available();
                        if(bytesAvailable > 0)
                        {
                            byte[] packetBytes = new byte[bytesAvailable];
                            int a = mInputStream.read(packetBytes);
                            ByteTreatement(packetBytes,a);
                        }
                    }
                    catch (IOException ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });
        workerThread.start();
    }

///////////////////////////////////////////////////////////////////////////////////////////
    /*  Function ByteTreatement() : decompose the received bytes and  interpret the results
     *  => Compare with these values : a=97  b=98    c=99  t=116   x=120   y=121   space=32
     */
    public void ByteTreatement(byte[] incomingByte, int iLength){
        //Log.d("DEBUGGER="," ByteTreatement"); // for real-time debbuging with USB in the Logcat (Android Studio)
        byte[] toShow=new byte[iLength];
        int j=0;
        for (int i=0; i<iLength;i++){
            if(incomingByte[i]!=0) {
                toShow[j] = incomingByte[i];
                j++;
            }
        }
        if(j!=iLength){

            for(int i=j; i<toShow.length;i++){
                toShow[i]=32;
            }
        }
        String valueString=null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            valueString = new String(toShow, StandardCharsets.UTF_8);

        }
        //Log.d("VALUE=", valueString); // for real-time debbuging with USB in the Logcat (Android Studio)
        switch(incomingByte[1]){
            case(97): // a
                distanceFromObstacle.setText(valueString);
                break;
            case(98):// b
                leftEncoder.setText(valueString);
                break;
            case(99):// c
                rightEncoder.setText(valueString);
                break;
            case(120)://x
                xPosition.setText(valueString);
                break;
            case(121)://y
                yPosition.setText(valueString);
                break;
            case(116): //t
                robotOrientation.setText(valueString);
                break;
        }
    }
/////////////////////////////////////////////////OK////////////////////////////////////////
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent)
        {
            //Log.d("DEBUGGER=","BroadcastReceiver bluetoothReceiver"); // for real-time debbuging with USB in the Logcat (Android Studio)
            String action = intent.getAction();
            if (action != null && action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                Current_State_Bluetooth(intent);
            }
        }
    };
//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////OK////////////////////////////////////////////////
    //  Function Current_State_Bluetooth() : manages the bluetooth Textbox
    public void Current_State_Bluetooth(Intent intent) {
        String[] BluetoothText={"Bluetooth off","Turning Bluetooth off...","Bluetooth on","Turning Bluetooth on..."};
        //Log.d("DEBUGGER=", "Current_State_Bluetooth"); // for real-time debbuging with USB in the Logcat (Android Studio)
        final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                BluetoothAdapter.ERROR);
        switch (state) {
            case BluetoothAdapter.STATE_OFF:
                txtBluetooth.setText(BluetoothText[0]);
                break;
            case BluetoothAdapter.STATE_TURNING_OFF:
                 txtBluetooth.setText(BluetoothText[1]);
                break;
            case BluetoothAdapter.STATE_ON:
                txtBluetooth.setText(BluetoothText[2]);
                break;
            case BluetoothAdapter.STATE_TURNING_ON:
                txtBluetooth.setText(BluetoothText[3]);
                break;
        }
    }
//////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////OK////////////////////////////////////////////////
    // Function onDestroy() called when App is closed by the user. Cancel the bluetooth connection  and destroy the App.
    @Override
    protected void onDestroy() {
        //Log.d("DEBUGGER=","onDestroy"); // for real-time debbuging with USB in the Logcat (Android Studio)
        super.onDestroy();
        bluetoothAdapter.cancelDiscovery();
        unregisterReceiver(bluetoothReceiver);
        if(bluetoothAdapter.isEnabled()){
            bluetoothAdapter.disable();
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
}