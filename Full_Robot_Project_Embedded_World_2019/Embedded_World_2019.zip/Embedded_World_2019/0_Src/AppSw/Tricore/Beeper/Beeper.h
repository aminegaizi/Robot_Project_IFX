/*
 * Beeper.h
 *
 *  Created on: 18.12.2018
 *      Author: Gaizi
 */

#ifndef BEEPER_H_
#define BEEPER_H_

#include "PWM_config.h"
#include "Bsp.h"
#include "Config_PWM.h"
#include "Tft.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"

void beep(void);

#endif /* 0_SRC_APPSW_TRICORE_BEEPER_BEEPER_H_ */
